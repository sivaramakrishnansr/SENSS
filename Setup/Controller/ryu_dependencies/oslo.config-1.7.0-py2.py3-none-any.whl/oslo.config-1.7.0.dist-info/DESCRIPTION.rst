==========================
Oslo Configuration Library
==========================

The Oslo configuration API supports parsing command line arguments and
.ini style configuration files.

* License: Apache License, Version 2.0
* Documentation: http://docs.openstack.org/developer/oslo.config
* Source: http://git.openstack.org/cgit/openstack/oslo.config
* Bugs: http://bugs.launchpad.net/oslo



