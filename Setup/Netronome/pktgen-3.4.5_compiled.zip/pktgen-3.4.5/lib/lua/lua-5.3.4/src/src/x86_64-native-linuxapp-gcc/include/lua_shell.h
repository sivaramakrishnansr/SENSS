/*-
 * Copyright (c) <2010-2017>, Intel Corporation. All rights reserved.
 *
 * SPDX-License-Indentifier: BSD-3-Clause
 */
/* Created 2011 by Keith Wiles @ intel.com */

#ifndef LUA_SHELL_H_
#define LUA_SHELL_H_

#define lua_c
#include "lua.h"
#include "lauxlib.h"

#ifdef __cplusplus
extern "C" {
#endif

#define IO_PREFIX       "_IO_"
#define IOPREF_LEN      (sizeof(IO_PREFIX)/sizeof(char) - 1)
#define IO_INPUT        (IO_PREFIX "input")
#define IO_OUTPUT       (IO_PREFIX "output")

#define MAX_NEW_LIBS	16
typedef void (*newlib_t)(lua_State * L);

int lua_newlib_add(newlib_t n);
void lua_newlibs_init(lua_State * L);

LUALIB_API int luaL_setprivate(lua_State * L, void * val);
LUALIB_API void * luaL_getprivate(lua_State * L);

LUA_API void (lua_setprivate) (lua_State * L, void * val) ;
LUA_API void * (lua_getprivate) (lua_State * L);

void createstdfile (lua_State *L, FILE *f, const char *k,
                           const char *fname);

#ifdef __cplusplus
}
#endif

#endif /* LUA_SHELL_H_ */
